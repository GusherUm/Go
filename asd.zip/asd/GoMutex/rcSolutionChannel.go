package main

import (
	"fmt"
	"sync"
)

var x = 0

func increment(wg *sync.WaitGroup, ch chan bool) {
	ch <- true // Indicating go routine is entering the critical section
	x = x + 1
	<-ch      // Indicating go routine is exiting the critical section
	wg.Done() // Decrementing the value of wait group.(sice we added 1 to it before)
}

func main() {
	var w sync.WaitGroup
	ch := make(chan bool, 1)

	for i := 0; i < 500; i++ {
		w.Add(1)
		go increment(&w, ch)
	}
	w.Wait()

	fmt.Println("final value of x", x)
}
