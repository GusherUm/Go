package main

import "fmt"

func main() {
    var a int = 10
    const b string = "Hello"
    fmt.Println(a, b)
}