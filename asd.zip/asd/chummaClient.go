package main

import (
	"log"
	"net/rpc"
)

type Args struct {
	A, B int
}

func main() {
	args := Args{10, 5}
	var reply int

	client, err := rpc.DialHTTP("tcp", "localhost:1234")
	if err != nil {
		log.Fatal("dialing:", err)
	}

	err = client.Call("Arith.Add", args, &reply)
	if err != nil {
		log.Fatal("arith error:", err)
	}
	log.Printf("Arith.Add(%d, %d) = %d", args.A, args.B, reply)

	err = client.Call("Arith.Subtract", args, &reply)
	if err != nil {
		log.Fatal("arith error:", err)
	}
	log.Printf("Arith.Subtract(%d, %d) = %d", args.A, args.B, reply)
}
