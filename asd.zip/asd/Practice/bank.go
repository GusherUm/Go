package main

import (
	"fmt"
	"sync"
)

var (
	mutex   sync.Mutex
	balance int
)

func init() {
	balance = 1000
}

func deposit(w *sync.WaitGroup, amount int) {
	mutex.Lock()

	balance += amount
	mutex.Unlock()
	w.Done()
}

func withdraw(w *sync.WaitGroup, amount int) {
	mutex.Lock()

	balance -= amount
	mutex.Unlock()
	w.Done()
}

func main() {

	var wg sync.WaitGroup
	wg.Add(2)
	go withdraw(&wg, 700)
	go deposit(&wg, 500)
	wg.Wait()

	fmt.Println("The final balance is: ", balance)
}
