package main

import (
	"fmt"
	"sync"
)

var x = 0

func increment(w *sync.WaitGroup, ch chan bool) {
	ch <- true
	x += 1
	<-ch
	w.Done()
}

func main() {
	var w sync.WaitGroup
	ch := make(chan bool, 1)

	for i := 0; i < 500; i++ {
		w.Add(1)
		go increment(&w, ch)
	}

	w.Wait()
	fmt.Println("The final value of x is: ", x)
}
