package main

import(
	"log"
	"net"
	"net/rpc"
	"net/http"
)

type Args struct{
	x int, 
	y int
}

func main(){

	args := Args{10, 5}
	var reply int

	Client.DialHTTP()

	Client.Call(&args, reply)
}