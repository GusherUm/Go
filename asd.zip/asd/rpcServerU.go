package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"net/rpc"
)

type Args struct {
	x int
	y int
}

type Arith struct{}

func (a *Arith) Add(args *Args, reply *int) error {
	*reply = args.x + args.y
	return nil
}

func (a *Arith) Subtract(args *Args, reply *int) error {
	*reply = args.x - args.y
	return nil
}

func main() {
	arith := new(Arith)
	rpc.Register(arith)
	rpc.HandleHTTP()

	l, err := net.Listen("tcp", ":1234")
	if err != nil {
		log.Fatal("There is an error")
	}

	fmt.Println("Server is listening...")
	http.Serve(l, nil)
}
